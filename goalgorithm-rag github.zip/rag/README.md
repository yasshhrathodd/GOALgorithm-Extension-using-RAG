# GOALgorithm RAG layer

A small, fully local RAG (Retrieval-Augmented Generation) demo on top of GOALgorithm. You ask a
natural-language question about Messi's and Ronaldo's passing-network centrality, and the answer is
grounded in the results already computed and stored in the project's MySQL database. No paid API.

This is a learning project: a working end-to-end pipeline on a small, clean dataset, not a production system.

## How it works

1. **Chunking.** Each (player, metric, match) value becomes one fact-only sentence, for example
   "In the 2022 FIFA World Cup match against France on 18 December 2022, Messi had a betweenness
   centrality of 0.03." The 47 player-match records times 3 metrics give 141 chunks.
2. **Metadata.** Each chunk carries `player`, `metric` and a `bucket` (high/low) as metadata.
   The bucket is deliberately not part of the sentence text.
3. **Retrieval.** If the question names a player or metric, or says "high" or "low", chunks are
   filtered by metadata first. Cosine similarity (sentence-transformers `all-MiniLM-L6-v2`) then
   ranks only the chunks that survived.
4. **Generation.** The top chunks and their buckets are placed in a prompt for a local Ollama model
   (`llama3.2`) with the rule: answer only from these facts, otherwise say you don't have it.

## Design decision: per-metric median buckets

The first plan was a fixed cutoff (0.5) for high versus low. Real data broke it: betweenness never
reaches 0.5 in any record (max about 0.33), degree is above 0.5 in every record, and closeness is not on a
0 to 1 scale (roughly 2.5 to 11.6). So "high" means strictly above that metric's own median, computed
across both players so they share one scale (medians: betweenness 0.026, degree 0.867, closeness 5.237).

## Setup

```bash
pip install -r requirements.txt
# Install Ollama (ollama.com), then:
ollama pull llama3.2

export GOAL_DB_PASSWORD=your_mysql_password   # Windows PowerShell: $env:GOAL_DB_PASSWORD="..."
python goalgorithm_rag.py      # retrieval only
python goalgorithm_answer.py   # retrieval plus generation
```

The loader expects the schema in `database/schema.sql` with the data loaded. If the World Cup rows in
`matches` have NULL `match_date` or `away_team_id`, run `fix_worldcup_matches.sql` once; otherwise
those matches produce chunks with no opponent or date and cannot be told apart.

## Known limitations

- **Implicit high/low.** A question like "when did Messi dominate the passing?" has no "high" in it,
  so no bucket filter is applied.
- **False refusal.** "What was Messi's betweenness against France in the World Cup final?" was refused
  even though the matching chunk exists. Likely cause: the chunk never mentions the match stage
  ("final"), so the model could not confirm it. Adding the stage to the sentence would be the fix.
- **No similarity threshold.** Off-topic questions without filter words still retrieve the nearest
  chunks. The prompt rule is the only guard before generation.
- **Embeddings and numbers.** Matching is driven mostly by the words in a chunk, not its value, so
  chunks for the same player and metric score almost identically.
- **Small `top_k`.** Questions that match many chunks (for example 18 Clasicos) need a larger `top_k`.

## Possible next steps

Add a similarity threshold, put the match stage in the chunk text, filter on opponent as well as
player and metric, and build a 15 to 20 question test set to measure how often answers are correct.
