-- Fills in dates, season and both teams for the 11 World Cup matches.
-- Run this only if match_date / away_team_id are NULL for rows where competition LIKE 'WC%'.
-- Dates and team names are from StatsBomb open data (match_id matches results_summary.json).
-- Requires the teams below to exist in `teams` (INSERT IGNORE them first if not).
USE goalgorithm;

UPDATE matches SET match_date='2022-11-22', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Argentina'), away_team_id=(SELECT team_id FROM teams WHERE name='Saudi Arabia') WHERE match_id=3857300;
UPDATE matches SET match_date='2022-11-26', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Argentina'), away_team_id=(SELECT team_id FROM teams WHERE name='Mexico') WHERE match_id=3857289;
UPDATE matches SET match_date='2022-11-30', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Poland'), away_team_id=(SELECT team_id FROM teams WHERE name='Argentina') WHERE match_id=3857264;
UPDATE matches SET match_date='2022-12-03', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Argentina'), away_team_id=(SELECT team_id FROM teams WHERE name='Australia') WHERE match_id=3869151;
UPDATE matches SET match_date='2022-12-09', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Netherlands'), away_team_id=(SELECT team_id FROM teams WHERE name='Argentina') WHERE match_id=3869321;
UPDATE matches SET match_date='2022-12-13', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Argentina'), away_team_id=(SELECT team_id FROM teams WHERE name='Croatia') WHERE match_id=3869519;
UPDATE matches SET match_date='2022-12-18', season='2022', home_team_id=(SELECT team_id FROM teams WHERE name='Argentina'), away_team_id=(SELECT team_id FROM teams WHERE name='France') WHERE match_id=3869685;
UPDATE matches SET match_date='2018-06-15', season='2018', home_team_id=(SELECT team_id FROM teams WHERE name='Portugal'), away_team_id=(SELECT team_id FROM teams WHERE name='Spain') WHERE match_id=7576;
UPDATE matches SET match_date='2018-06-20', season='2018', home_team_id=(SELECT team_id FROM teams WHERE name='Portugal'), away_team_id=(SELECT team_id FROM teams WHERE name='Morocco') WHERE match_id=7542;
UPDATE matches SET match_date='2018-06-25', season='2018', home_team_id=(SELECT team_id FROM teams WHERE name='Iran'), away_team_id=(SELECT team_id FROM teams WHERE name='Portugal') WHERE match_id=7557;
UPDATE matches SET match_date='2018-06-30', season='2018', home_team_id=(SELECT team_id FROM teams WHERE name='Uruguay'), away_team_id=(SELECT team_id FROM teams WHERE name='Portugal') WHERE match_id=7579;
