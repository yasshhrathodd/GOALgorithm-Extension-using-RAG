"""Generation step: retrieved chunks plus the question go to a local Ollama model.

Run from this folder. Requires goalgorithm_rag.py (same folder) and Ollama with llama3.2 pulled.
"""
import ollama

from goalgorithm_rag import search

MODEL = "llama3.2"


def build_prompt(question, results):
    # The bucket is metadata. It is passed next to each fact so the model can say "high" or "low".
    facts = "\n".join(f"- {text} (bucket: {bucket})" for text, bucket, _ in results)
    return (
        "You answer questions about the passing-network centrality of Messi and Ronaldo.\n"
        "Use ONLY the facts listed below. Copy numbers exactly as written.\n"
        "If the facts do not contain the answer, reply: I don't have that in the data.\n"
        "Do not use outside knowledge.\n\n"
        f"Facts:\n{facts}\n\n"
        f"Question: {question}\nAnswer:"
    )


def answer(question, top_k=8):
    results = search(question, top_k=top_k)  # retrieval: metadata filter, then cosine similarity
    if not results:
        return "I don't have that in the data."
    prompt = build_prompt(question, results)
    reply = ollama.chat(model=MODEL, messages=[{"role": "user", "content": prompt}])  # generation
    return reply["message"]["content"]


if __name__ == "__main__":
    for q in [
        "What was Messi's betweenness against France in the World Cup final?",
        "Show me a high closeness match for Ronaldo",
        "Who won the 2018 World Cup?",  # not in the data: the model should refuse
    ]:
        print("\nQ:", q)
        print("A:", answer(q))
