"""GOALgorithm RAG: retrieval over player-match centrality results.

1. Load player-match centrality results from MySQL.
2. Turn each (match, metric) value into one fact-only sentence (the chunk).
3. Bucket (high/low) = per-metric median split. Stored as metadata, never in the text.
4. Search: filter by metadata first, then cosine similarity on what is left.

Database settings are read from environment variables (defaults in brackets):
GOAL_DB_HOST [localhost], GOAL_DB_USER [root], GOAL_DB_PASSWORD [empty], GOAL_DB_NAME [goalgorithm]
"""
import os

import mysql.connector
import numpy as np
from sentence_transformers import SentenceTransformer

DB = {
    "host": os.environ.get("GOAL_DB_HOST", "localhost"),
    "user": os.environ.get("GOAL_DB_USER", "root"),
    "password": os.environ.get("GOAL_DB_PASSWORD", ""),
    "database": os.environ.get("GOAL_DB_NAME", "goalgorithm"),
}

QUERY = """
    SELECT p.display_name AS player, m.competition, m.season,
           DATE_FORMAT(m.match_date, '%d %M %Y') AS date, t.name AS opponent,
           s.degree_centrality, s.betweenness_centrality, s.closeness_centrality
    FROM player_match_stats s
    JOIN players p ON p.player_id = s.player_id
    JOIN matches m ON m.match_id = s.match_id
    LEFT JOIN teams t ON t.team_id = CASE WHEN m.home_team_id = s.team_id
                                          THEN m.away_team_id ELSE m.home_team_id END
"""

METRICS = [("degree_centrality", "degree centrality"),
           ("betweenness_centrality", "betweenness centrality"),
           ("closeness_centrality", "closeness centrality")]

COMP = {"WC2018": "2018 FIFA World Cup", "WC2022": "2022 FIFA World Cup"}


def load_rows():
    con = mysql.connector.connect(**DB)
    cur = con.cursor(dictionary=True)
    cur.execute(QUERY)
    rows = []
    for r in cur.fetchall():
        for col, name in METRICS:
            if r[col] is None:
                continue
            rows.append({"player": r["player"], "competition": r["competition"],
                         "season": r["season"], "date": r["date"],
                         "opponent": r["opponent"], "metric": name, "value": float(r[col])})
    con.close()
    return rows


def make_chunk(m):
    """One fact-only sentence. No interpretation and no high/low label."""
    comp = COMP.get(m["competition"], m["competition"])
    season = f" {m['season']}" if m["season"] and m["season"] not in comp else ""
    opp = f" against {m['opponent']}" if m["opponent"] else ""
    when = f" on {m['date']}" if m["date"] else ""
    return f"In the {comp}{season} match{opp}{when}, {m['player']} had a {m['metric']} of {m['value']:.2f}."


rows = load_rows()

# Per-metric median over ALL rows (both players), so Messi and Ronaldo share one scale.
medians = {}
for name in {r["metric"] for r in rows}:
    medians[name] = float(np.median([r["value"] for r in rows if r["metric"] == name]))


def bucket(metric, value):
    return "high" if value > medians[metric] else "low"  # a value equal to the median counts as low


print("Median per metric:", {k: round(v, 3) for k, v in medians.items()})
print("Total chunks:", len(rows))

model = SentenceTransformer("all-MiniLM-L6-v2")
chunks = [make_chunk(r) for r in rows]
meta = [{"player": r["player"].lower(), "metric": r["metric"],
         "bucket": bucket(r["metric"], r["value"])} for r in rows]
vectors = model.encode(chunks, normalize_embeddings=True)  # unit length, so dot product = cosine


def search(question, top_k=3):
    """Filter by metadata first, then rank the survivors by cosine similarity."""
    q = question.lower()
    words = q.replace("?", "").replace(",", "").split()

    def keep(m):
        if "high" in words and m["bucket"] != "high":
            return False
        if "low" in words and m["bucket"] != "low":
            return False
        for name in ("messi", "ronaldo"):
            if name in q and name not in m["player"]:
                return False
        for metric in ("betweenness", "closeness", "degree"):
            if metric in q and metric not in m["metric"]:
                return False
        return True

    ids = [i for i, m in enumerate(meta) if keep(m)]  # filter FIRST
    if not ids:
        return []
    q_vec = model.encode(question, normalize_embeddings=True)
    scores = vectors[ids] @ q_vec                      # then cosine similarity
    best = np.argsort(-scores)[:top_k]
    return [(chunks[ids[j]], meta[ids[j]]["bucket"], float(scores[j])) for j in best]


if __name__ == "__main__":
    for question in [
        "What was Messi's betweenness against Real Madrid?",
        "Show me a high closeness match for Ronaldo",
        "Which match had low degree centrality for Messi?",
    ]:
        print("\nQ:", question)
        results = search(question)
        if not results:
            print("  No chunks matched those filters.")
        for text, b, score in results:
            print(f"  [{b}] ({score:.2f}) {text}")
